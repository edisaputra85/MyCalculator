package com.saputra.edi.mycalculator;

import android.animation.TypeConverter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    String mathString;
    String operator;
    Double operand1;
    Double operand2;
    TextView txt;

    protected void onCreate(Bundle savedInstanceState) {
        mathString="0";
        operator= "";
        operand1 = 0.0;
        operand2 = 0.0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txt = findViewById(R.id.textView);
        txt.setText(mathString);
    }

    public void buttonClicked(View view) {
        CharSequence prevText = txt.getText();
        switch (view.getId())
        {
            case R.id.button7:
                if (mathString.equals("0")) {
                    mathString ="7";
                    txt.setText(mathString);
                }
                else {
                    mathString += "7";
                    txt.setText(mathString);
                }
                break;
            case R.id.button8:
                if (mathString.equals("0")) {
                    mathString ="8";
                    txt.setText(mathString);
                }
                else {
                    mathString += "8";
                    txt.setText(mathString);
                }
                break;
            case R.id.button9:
                if (mathString.equals("0")) {
                    mathString ="9";
                    txt.setText(mathString);
                }
                else {
                    mathString += "9";
                    txt.setText(mathString);
                }
                break;
            case R.id.button4:
                if (mathString.equals("0")) {
                    mathString ="4";
                    txt.setText(mathString);
                }
                else {
                    mathString += "4";
                    txt.setText(mathString);
                }
                break;
            case R.id.button5:
                if (mathString.equals("0")) {
                    mathString ="5";
                    txt.setText(mathString);
                }
                else {
                    mathString += "5";
                    txt.setText(mathString);
                }
                break;
            case R.id.button6:
                if (mathString.equals("0")) {
                    mathString ="6";
                    txt.setText(mathString);
                }
                else {
                    mathString += "6";
                    txt.setText(mathString);
                }
                break;
            case R.id.button1:
                if (mathString.equals("0")) {
                    mathString ="1";
                    txt.setText(mathString);
                }
                else {
                    mathString += "1";
                    txt.setText(mathString);
                }
                break;
            case R.id.button2:
                if (mathString.equals("0")) {
                    mathString ="2";
                    txt.setText(mathString);
                }
                else {
                    mathString += "2";
                    txt.setText(mathString);
                }
                break;
            case R.id.button3:
                if (mathString.equals("0")) {
                    mathString ="3";
                    txt.setText(mathString);
                }
                else {
                    mathString += "3";
                    txt.setText(mathString);
                }
                break;
            case R.id.button0:
                if (mathString.equals("0")) {
                    mathString ="0";
                    txt.setText(mathString);
                }
                else {
                    mathString += "0";
                    txt.setText(mathString);
                }
                break;
            case R.id.buttonDot:
                if (mathString.equals("0")) {
                    mathString = "0.";
                    txt.setText(mathString);
                }
                else if (mathString.contains(".")) ;
                else {
                    mathString += ".";
                    txt.setText(mathString);
                }
                break;
            case R.id.buttonAC:
                mathString ="0";
                operator="";
                operand1 = 0.0;
                operand2 = 0.0;
                txt.setText(mathString);
                break;
            case R.id.buttonDelete:
                if (mathString.length()==1){
                    mathString ="0";
                    txt.setText(mathString);
                }
                else {
                    mathString = mathString.substring(0, mathString.length() - 1);
                    txt.setText(mathString);
                }
                break;
            case R.id.buttonPlusMinus:
                    Double temp = (Double.parseDouble(mathString) * (-1));
                    mathString = Double.toString(temp);
                    txt.setText(mathString);
                break;
            case R.id.buttonDivide:
                if (operator.equals("")) {
                    operand1 = Double.parseDouble (mathString);
                    mathString = "0";
                    operator ="/";
                }
                else{
                    if (mathString.equals("0")) break;//pembagi nol tidak diizinkan
                    else operand2 = Double.parseDouble (mathString);
                    DecimalFormat df = new DecimalFormat("#.##");
                    if (operator.equals("/")) operand1 = operand1 / operand2;
                    else if (operator.equals("*")) operand1 = operand1 * operand2;
                    else if (operator.equals("+")) operand1 = operand1 + operand2;
                    else if (operator.equals("-")) operand1 = operand1 - operand2;
                    txt.setText(df.format(operand1));
                    mathString = "0";
                    operator ="/";
                }
                break;
            case R.id.buttonMultiply:
                if (operator.equals("")) {
                    operand1 = Double.parseDouble (mathString);
                    mathString = "0";
                    operator ="*";
                }
                else{
                    if (mathString.equals("0")) break;//pembagi nol tidak diizinkan
                    else operand2 = Double.parseDouble (mathString);
                    DecimalFormat df = new DecimalFormat("#.##");
                    if (operator.equals("/")) operand1 = operand1 / operand2;
                    else if (operator.equals("*")) operand1 = operand1 * operand2;
                    else if (operator.equals("+")) operand1 = operand1 + operand2;
                    else if (operator.equals("-")) operand1 = operand1 - operand2;
                    txt.setText(df.format(operand1));
                    mathString = "0";
                    operator ="*";
                }
                break;
            case R.id.buttonMinus:
                if (operator.equals("")) {
                    operand1 = Double.parseDouble (mathString);
                    mathString = "0";
                    operator ="-";
                }
                else{
                    if (mathString.equals("0")) break;//pembagi nol tidak diizinkan
                    else operand2 = Double.parseDouble (mathString);
                    DecimalFormat df = new DecimalFormat("#.##");
                    if (operator.equals("/")) operand1 = operand1 / operand2;
                    else if (operator.equals("*")) operand1 = operand1 * operand2;
                    else if (operator.equals("+")) operand1 = operand1 + operand2;
                    else if (operator.equals("-")) operand1 = operand1 - operand2;
                    txt.setText(df.format(operand1));
                    mathString = "0";
                    operator ="-";
                }
                break;
            case R.id.buttonPlus:
                if (operator.equals("")) {
                    operand1 = Double.parseDouble (mathString);
                    mathString = "0";
                    operator ="+";
                }
                else{
                    if (mathString.equals("0")) break;//pembagi nol tidak diizinkan
                    else operand2 = Double.parseDouble (mathString);
                    DecimalFormat df = new DecimalFormat("#.##");
                    if (operator.equals("/")) operand1 = operand1 / operand2;
                    else if (operator.equals("*")) operand1 = operand1 * operand2;
                    else if (operator.equals("+")) operand1 = operand1 + operand2;
                    else if (operator.equals("-")) operand1 = operand1 - operand2;
                    txt.setText(df.format(operand1));
                    mathString = "0";
                    operator ="+";
                }
                break;
            case R.id.buttonEqual:
                if (operator.equals(""));
                else{
                    if (mathString.equals("0")) break;//pembagi nol tidak diizinkan
                    else operand2 = Double.parseDouble (mathString);
                    DecimalFormat df = new DecimalFormat("#.##");
                    if (operator.equals("/")) operand1 = operand1 / operand2;
                    else if (operator.equals("*")) operand1 = operand1 * operand2;
                    else if (operator.equals("+")) operand1 = operand1 + operand2;
                    else if (operator.equals("-")) operand1 = operand1 - operand2;
                    txt.setText(df.format(operand1));
                    mathString = operand1.toString();
                    operator ="";
                }
                break;
        }
    }
}
